import React, { useState } from 'react';

const Dashboard = () => {
  // Replace this state with the actual name received from the form submission
  const [reporterName, setReporterName] = useState('Muvunyi Bruce'); // Example placeholder name

  return (
    <div className="flex justify-center items-center min-h-screen bg--100">
    <div className="container mx-auto p-4 ">
      {/* Name Display Section */}
      <div className="mb-6">
        <h1 className="text-2xl text-indigo-600">utanze Raporo: {reporterName}</h1>
        <h2 className="text-xl mt-2 font-bold text-center">RAPORO Y'IBIORI BYINJIYE MU RUGANDA</h2>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto mb-8">
        <table className="min-w-full border-collapse border border-indigo-500">
          <thead className="bg-indigo-100">
            <tr>
              <th className="border border-indigo-500 px-4 py-2">Itariki</th>
              <th className="border border-indigo-500 px-4 py-2">Amazina y'ugemuye</th>
              <th className="border border-indigo-500 px-4 py-2">Plake y'Imodoka</th>
              <th className="border border-indigo-500 px-4 py-2">Ingano y'Ibyinjiye</th>
              <th className="border border-indigo-500 px-4 py-2">Ubwume bw'Ibigori</th>
              <th className="border border-indigo-500 px-4 py-2">Uruhumbu</th>
              <th className="border border-indigo-500 px-4 py-2">Igiciro</th>
              <th className="border border-indigo-500 px-4 py-2">Amafaranga Asabwa</th>
              <th className="border border-indigo-500 px-4 py-2">Amafaranga Yishyuwe</th>
              <th className="border border-indigo-500 px-4 py-2">Amafaranga Asigaye</th>
            </tr>
          </thead>
          <tbody>
            {/* Replace with dynamic data*/}
            <tr>
              <td className="border border-indigo-500 px-4 py-2">05/11/2024</td>
              <td className="border border-indigo-500 px-4 py-2">Pablos</td>
              <td className="border border-indigo-500 px-4 py-2">RAD 123B</td>
              <td className="border border-indigo-500 px-4 py-2">900 kg</td>
              <td className="border border-indigo-500 px-4 py-2">700kg</td>
              <td className="border border-indigo-500 px-4 py-2">200kg</td>
              <td className="border border-indigo-500 px-4 py-2">500Frw/kg</td>
              <td className="border border-indigo-500 px-4 py-2">40000Frw</td>
              <td className="border border-indigo-500 px-4 py-2">35000Frw</td>
              <td className="border border-indigo-500 px-4 py-2">5000FRW</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* ahajya ibihari muri stock byose */}
      <div className="mb-6">
        <h2 className="text-xl mb-6 text-center  font-bold">AMAKURU Y'UBUBIKO BUHARI</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full border-collapse border border-indigo-500">
            <thead className="bg-indigo-100">
              <tr>
                <th className="border border-indigo-500 px-4 py-2">Ingano y'Ibigori Byari Bihari</th>
                <th className="border border-indigo-500 px-4 py-2">Ingano y'Ibigori Byiyongereye</th>
                <th className="border border-indigo-500 px-4 py-2">Igiteranyo cy'Ibigori Bihari</th>
              </tr>
            </thead>
            <tbody>
              {/* Replace with dynamic data/ bizajya byijyanamo  */}
              <tr>
                <td className="border border-indigo-500 px-4 py-2">3.Tn</td>
                <td className="border border-indigo-500 px-4 py-2">900 kg</td>
                <td className="border border-indigo-500 px-4 py-2">3.9Tn</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </div>
  );
};

export default Dashboard;

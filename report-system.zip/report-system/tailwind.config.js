module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        indigo: {
          DEFAULT: '#4f46e5',
          // Add additional shades if needed
        },
      },
    },
  },
  plugins: [],
};

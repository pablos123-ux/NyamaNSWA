

## Pablo oe gira 



1. Ensure you have Node.js and npm installed on your system.
2. Clone this repository to your local machine.
3. Navigate to the project directory and run `npm install` to install dependencies.
4. Run `npm run dev` to start the development server.
5. Open your browser and navigate to `http://localhost:3000` to view the application.

#### Noneh nurangiza ugende uhindura amagambo yumweru gusa 